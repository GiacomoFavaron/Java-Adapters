package adapter.test;

import adapter.*;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

import java.util.NoSuchElementException;

/**
 * Test case class for MapAdapter values
 * @safe.summary This class tests all functionalities of the collection returned by the method values() of a MapAdapter
 */
public class TestMapAdapterValues {

    private HCollection c = null;
    private Object v1 = null;
    private Object v2 = null;
    private Object value1 = null;
    private Object value2 = null;

    /**
     * Setup (for all tests): initializes the HCollection c returned by the method values and containing 2 values. It also saves 4 values, 2 contained in c (v1, v2), 2 not contained in c (value1, value2).
     */

    @Before
    public void setUp() {
        MapAdapter map = new MapAdapter();
        map.put(Integer.valueOf(1), Integer.valueOf(2));
        map.put(Integer.valueOf(4), Integer.valueOf(5));
        c = map.values();
        HIterator it = c.iterator();
        v1 = it.next();
        v2 = it.next();
        MapAdapter map2 = new MapAdapter();
        map2.put(Integer.valueOf(10), Integer.valueOf(11));
        map2.put(Integer.valueOf(11), Integer.valueOf(12));
        HCollection s2 = map2.values();
        HIterator it2 = s2.iterator();
        value1 = it2.next();
        value2 = it2.next();
    }

    /**
     * Test add
     * @safe.precondition Setup
     * @safe.postcondition UnsupportedOperationException thrown
     * @safe.testcases Test that when calling add UnsupportedOperationException is thrown
     */
    @Test(expected = UnsupportedOperationException.class)
    public void testAdd() {
        c.add(new Object());
    }

     /**
     * Test addAll
     * @safe.precondition Setup
     * @safe.postcondition UnsupportedOperationException thrown
     * @safe.testcases Test that when calling addAll UnsupportedOperationException is thrown
     */
    @Test(expected = UnsupportedOperationException.class)
    public void testAddAll() {
        c.add(new CollectionAdapter());
    }

    /**
     * Test clear
     * @safe.precondition setup
     * @safe.postcondition collection is empty, size is 0
     * @safe.testcases Tests that after calling clear size is 0
     */
    @Test
    public void testClear() {
        c.clear();
        assertEquals(0, c.size());
    }

    /**
     * Test contains value contained
     * @safe.precondition setup
     * @safe.postcondition None
     * @safe.testcases Test that contains(v1) returns true.
     */
    @Test
    public void testContainsTrue() {
        assertTrue(c.contains(v1));
    }

    /**
     * Test contains value not contained
     * @safe.precondition setup
     * @safe.postcondition None
     * @safe.testcases Test that contains(value1) returns false.
     */
    @Test
    public void testContainsFalse() {
        assertFalse(c.contains(value1));
    }

    /**
     * Test contains with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that contains(null) throws NullPointerException
     */
    @Test(expected = NullPointerException.class)
    public void testContainsWithNull() {
        c.contains(null);
    }

    /**
     * Test containsAll with collection contained
     * @safe.precondition setup, collection coll initialized, v1 and v2 added to collection
     * @safe.postcondition None
     * @safe.testcases Test that containsAll(coll) returns true
     */
    @Test
    public void testContainsAllWithHCollectionContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(v1);
        coll.add(v2);
        assertTrue(c.containsAll(coll));
    }

    /**
     * Test containsAll with collection not contained
     * @safe.precondition setup, collection coll initialized, value1 and value2 added to collection
     * @safe.postcondition None
     * @safe.testcases Test that containsAll(coll) returns false
     */
    @Test
    public void testContainsAllWithHCollectionNotContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(value1);
        coll.add(value2);
        assertFalse(c.containsAll(coll));
    }

    /**
     * Test containsAll with collection partially contained
     * @safe.precondition setup, collection coll initialized, v1 and value2 added to collection
     * @safe.postcondition None
     * @safe.testcases Test that containsAll(coll) returns false
     */
    @Test
    public void testContainsAllWithHCollectionPartiallyContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(v1);
        coll.add(value1);
        assertFalse(c.containsAll(coll));
    }

    /**
     * Test containsAll with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that containsAll(null) throws NullPointerException
     */
    @Test(expected = NullPointerException.class)
    public void testContainsAllWithNull() {
        c.containsAll(null);
    }

    /**
     * Test equals with equal set
     * @safe.precondition setup, calls values to create otherCollection from map with the same values
     * @safe.postcondition None
     * @safe.testcases Test that c.equals(otherCollection) returns true.
     */
    @Test
    public void testEqualsTrue() {
        MapAdapter map = new MapAdapter();
        map.put(Integer.valueOf(1), Integer.valueOf(2));
        map.put(Integer.valueOf(4), Integer.valueOf(5));
        HCollection otherCollection = map.values();
        assertEquals(c, otherCollection);
    }

    /**
     * Test equals with different collections
     * @safe.precondition setup, otherCollection initialized, one object added to otherCollection
     * @safe.postcondition None
     * @safe.testcases Test that c.equals(otherCollection) returns false.
     */
    @Test
    public void testEqualsFalse() {
        HCollection otherCollection = new CollectionAdapter();
        otherCollection.add(new Object());
        assertFalse(c.equals(otherCollection));
    }

    /**
     * Test hashcode equal collections
     * @safe.precondition setup, calls values to create otherCollection from map with the same values
     * @safe.postcondition None
     * @safe.testcases Test that if collections are equal also hashcodes are equal 
     */
	@Test
    public void testHashCodeTrue() {
        MapAdapter map = new MapAdapter();
        map.put(Integer.valueOf(1), Integer.valueOf(2));
        map.put(Integer.valueOf(4), Integer.valueOf(5));
        HCollection otherCollection = map.values();
        assertEquals(c, otherCollection);
		assertTrue(c.hashCode() == otherCollection.hashCode());
	}
    
    /**
     * Test hashcode different collections
     * @safe.precondition collection c initialized, otherCollection initialized, objects added to s
     * @safe.postcondition None
     * @safe.testcases Test that if collections are not equal also hashcodes are not equal 
     */
	@Test
    public void testHashCodeFalse() {
        HCollection otherCollection = new CollectionAdapter();
        for(int i = 0; i < 5; i++) {
            otherCollection.add(new Object());
        }
		assertFalse(c.equals(otherCollection));
		assertFalse(c.hashCode() == otherCollection.hashCode());
	}

   /**
     * Test isEmpty with empty set
     * @safe.precondition setup, call to clear
     * @safe.postcondition None
     * @safe.testcases Test that isEmpty returns true
     */
    @Test
    public void TestIsEmptyTrue() {
        c.clear();
        assertTrue(c.isEmpty());
    }

     /**
     * Test isEmpty with non empty set
     * @safe.precondition setup
     * @safe.postcondition None
     * @safe.testcases Test that isEmpty returns false
     */
    @Test
    public void testIsEmptyFalse() {
        assertFalse(c.isEmpty());
	}

    /**
     * Test iterator next and hasNext
     * @safe.precondition setup, iterator initialized, otherCollection initialized
     * @safe.postcondition collection c copied into otherCollection
     * @safe.testcases Test that after iterating over the collection c with the iterator's methods next and hasNext and copying the elements returned by next into otherCollection, otherCollection is equal to c.
     */
    @Test
    public void testIteratorNextAndHasNext() {
        HIterator it = c.iterator();
        HCollection otherCollection = new CollectionAdapter();
        while(it.hasNext()) {
            otherCollection.add(it.next());
        }
        assertEquals(c, otherCollection);
	}

    /**
     * Test iterator NoSuchElementException
     * @safe.precondition setup, iterator initialized
     * @safe.postcondition NoSuchElementException thrown
     * @safe.testcases Test that calling next 3 causes NoSuchElementException to be thrown
     */
	@Test(expected = NoSuchElementException.class)
    public void testIteratorNextNoMoreElements() {
        HIterator it = c.iterator();
        for(int i = 0; i < 3; i++) {
            it.next();
		}
	}
    
    /**
     * Test iterator remove
     * @safe.precondition setup
     * @safe.postcondition One element removed from the set
     * @safe.testcases Test that calling it.next() and it.remove() causes the size of the collection to decrease by one
	 */
	@Test
    public void testIteratorRemove() {
		HIterator it = c.iterator();
		it.next();
        it.remove();
        assertEquals(1, c.size());
	}
    
	/**
     * Test remove when object is contained
     * @safe.precondition setup
     * @safe.postcondition value v1 has been removed from the set
     * @safe.testcases Test that calling remove(v1) removes that value from the collection and returns true (contains(v1) returns false)
     */
    @Test
    public void testRemoveTrue() {
        assertTrue(c.remove(v1));
        assertEquals(false, c.contains(v1));
    }

	/**
     * Test remove when object isn't contained
     * @safe.precondition setup
     * @safe.postcondition c hasn't been modified
     * @safe.testcases Test that calling remove(value1) returns false
     */
    @Test
    public void testRemoveFalse() {
        assertFalse(c.remove(value1));
    }

    /**
     * Test remove with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that remove(null) throws NullPointerException
     */
    @Test(expected = NullPointerException.class)
    public void testRemoveWithNull() {
        c.remove(null);
    }

	/**
     * Test removeAll with collection contained in the set
     * @safe.precondition setup, collection coll initialized, v1 added to coll
     * @safe.postcondition all elements in the collection have been removed from the set
     * @safe.testcases Test that calling removeAll(coll) removes the elements of coll from the collection (iterating over the collection and calling contains on the elements of coll returns false)
     */
    @Test
    public void testRemoveAllWithHCollectionContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(v1);
		assertTrue(c.removeAll(coll));
		HIterator cit = coll.iterator();
		while(cit.hasNext()) {
			assertFalse(c.contains(cit.next()));
		}
    }

	/**
     * Test removeAll with coll not contained in the set
     * @safe.precondition setup, value1 and value2 added to collection
     * @safe.postcondition None
     * @safe.testcases Test that calling removeAll(coll) returns false and the size of the collection is two
     */
    @Test
    public void testRemoveAllWithHCollectionNotContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(value1);
        coll.add(value2);
		assertFalse(c.removeAll(coll));
        assertEquals(2, c.size());
    }

    /**
     * Test removeAll with coll partially contained in the set
     * @safe.precondition setup, value1 and v2 added to coll
     * @safe.postcondition v2 has been removed from the set
     * @safe.testcases Test that calling removeAll(coll) returns true and removes v2 from the collection (size of the collection becomes 1)
     */
    @Test
    public void testRemoveAllCollectionPartiallyContained() {
        HCollection coll = new CollectionAdapter();
        coll.add(value1);
        coll.add(v2);
		assertTrue(c.removeAll(coll));
		assertEquals(1, c.size());
    }

    /**
     * Test removeAll with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that removeAll(null) throws NullPointerException
     */
    @Test(expected = NullPointerException.class)
    public void testRemoveAllWithNull() {
        c.removeAll(null);
    }

	/**
     * Test retainAll in a condition when all elements are retained
     * @safe.precondition setup, collection coll initailized, v1 and v2 added to coll
     * @safe.postcondition all objects are still in the set
     * @safe.testcases Test that calling retainAll(coll) retains all the elements of coll in the collection (retainAll returns false, since the collection hasn't been modified and the size of the collection is still 2)
     */
    @Test
    public void testRetainAllAllElementsRetained() {
        HCollection coll = new CollectionAdapter();
        coll.add(v1);
        coll.add(v2);
		assertFalse(c.retainAll(coll));
		assertEquals(2, c.size());
    }

	/**
     * Test retainAll in a condition when some elements are retained
     * @safe.precondition setup, collection coll initailized, v1 added to coll
     * @safe.postcondition One element retained
     * @safe.testcases Test that calling retainAll(coll) retains the one value in coll and removes the other one (retainAll returns true, since the collection has been modified and the size of the collection is now 1)
     */
    @Test
    public void testRetainAllSomeElementsRetained() {
        HCollection coll = new CollectionAdapter();
        coll.add(v1);
		assertTrue(c.retainAll(coll));
		assertEquals(1, c.size());
	}

    /**
     * Test retainAll in a condition when no elements are retained
     * @safe.precondition setup, collection coll initailized, value1 added to coll
     * @safe.postcondition The collection is empty
     * @safe.testcases Test that calling retainAll(coll) retains no elements (retainAll returns true, since the collection has been modified and the size of the collection is now 0)
     */
	@Test
    public void testRetainAllNoElementsRetained() {
        HCollection coll = new CollectionAdapter();
		coll.add(value1);
		assertTrue(c.retainAll(coll));
		assertEquals(0, c.size());
	}

    /**
     * Test retainAll with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that retainAll(null) throws NullPointerException
     */
	@Test(expected = NullPointerException.class)
    public void testRetainAllWithNull() {
        c.retainAll(null);
	}

   	 /**
     * Test size with an empty collection 
     * @safe.precondition setup, call to clear
     * @safe.postcondition None
     * @safe.testcases Test that calling size with an empty collection returns 0
     */
    @Test
    public void testSizeEmpty() {
        c.clear();
        assertEquals(0, c.size());
    }

     /**
     * Test size
     * @safe.precondition setup
     * @safe.postcondition None
     * @safe.testcases Test that calling size retrns 2
     */
    @Test
    public void testSize() {
        assertEquals(2, c.size());
    }

    /**
     * Test toArray 
     * @safe.precondition setup
     * @safe.postcondition collectionArray contains the array view of the set
     * @safe.testcases Test that calling toArray returns an array with the same elements as the collection in the same order returned by the collection iterator.
     */
    @Test
    public void testToArray() {
        Object[] collectionArray = c.toArray();
        HIterator it = c.iterator();
		int j = 0;
        while(it.hasNext()) {
			assertEquals(it.next(), collectionArray[j]);
			j++;
        }
    }

    /**
     * Test toArray(Object[]) with an array of length smaller than the size of the set
     * @safe.precondition setup, Object array param of length 1 initialized
     * @safe.postcondition collectionArray contains the array view of the set
     * @safe.testcases Test that calling toArray(param) returns an array with the same elements as the collection in the same order returned by the collection iterator and of length the size of the set.
     */
    @Test
    public void testToArrayWithParameterSizeSmaller() {
        Object[] param = new Object[1];
        Object[] collectionArray = c.toArray(param);
        assertEquals(2, collectionArray.length);
        HIterator it = c.iterator();
		int j = 0;
        while(it.hasNext()) {
			assertEquals(it.next(), collectionArray[j]);
			j++;
        }
    }

    /**
     * Test toArray(Object[]) with an array of length greater than the size of the set
     * @safe.precondition setup, Object array param of length 10 initialized
     * @safe.postcondition collectionArray contains the array view of the set
     * @safe.testcases Test that calling toArray(param) returns an array with the same elements as the collection in the same order returned by the collection iterator and of length the length of param. The elements of the array after the index c.size()-1 are collection to null.
     */
    @Test
    public void testToArrayWithParameterSizeLonger() {
        Object[] param = new Object[10];
        Object[] collectionArray = c.toArray(param);
        assertEquals(10, collectionArray.length);
        HIterator it = c.iterator();
		int j = 0;
        while(it.hasNext()) {
			assertEquals(it.next(), collectionArray[j]);
			j++;
        }
        for(int i = c.size(); i < param.length; i++) {
            assertEquals(collectionArray[i], null);
        }
    }

	/**
     * Test toArray with null
     * @safe.precondition setup
     * @safe.postcondition NullPointerException thrown
     * @safe.testcases Test that calling toArray(null) throws NullPointerException.
     */
    @Test(expected = NullPointerException.class)
    public void testToArrayWithNull() {
        c.toArray(null);
    }

}